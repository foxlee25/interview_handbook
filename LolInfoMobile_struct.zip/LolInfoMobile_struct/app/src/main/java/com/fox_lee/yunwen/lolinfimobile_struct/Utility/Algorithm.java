package com.fox_lee.yunwen.lolinfimobile_struct.Utility;

/**
 * Created by Yunwen on 2/15/2016.
 */
public class Algorithm {
    //表名
    public static final String TABLE="Algorithm";

    //表的各域名
    public static final String KEY_ID="id";
    public static final String KEY_topic="topic";
    public static final String KEY_content="content";
    public static final String KEY_age="age";

    //属性
    public int algorithm_ID;
    public String topic;
    public String content;
    public int age;
}
