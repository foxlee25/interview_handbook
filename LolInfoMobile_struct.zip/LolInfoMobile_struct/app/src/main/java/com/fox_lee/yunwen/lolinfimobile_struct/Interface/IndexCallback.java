package com.fox_lee.yunwen.lolinfimobile_struct.Interface;

import java.util.ArrayList;

/**
 * Created by YOUHAI on 12/11/2015.
 */
public interface IndexCallback {
    void StartAlgorithmFragment(String var);
    void StartAlgorithmSubFragment(ArrayList<String> var[]);
    void StartJavaFragment(String var);
    void StartCardViewFragment(String var);
}
